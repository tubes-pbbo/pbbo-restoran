<footer>
    <div class="footer1">
      <p style="margin-bottom: -5px">Restaurant OKE</p>
      <p style="margin-top: -5px">Jalan Apa Aja Yang Penting Oke</p>
    </div>
</footer><?php /**PATH C:\Users\frans\PBBO\resources\views/footer.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/css/app.css" rel="stylesheet">
    <script src="/js/app.js" charset="utf=8"></script>
    <script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css" />
</head>
<style>
footer {

    color: #ffffff;
    text-align: center;
    padding: 25px;
}
</style>

<body>
    <nav class="navbar navbar-expand-md bg-dark navbar-dark">
        <footer>
            <p>Restaurant OKE</p> <br>
            <p>Jalan Apa Aja Yang Penting Oke</p>
        </footer>

    </nav>

</body>

</html><?php /**PATH /opt/lampp/htdocs/PBBO/resources/views/footer.blade.php ENDPATH**/ ?>
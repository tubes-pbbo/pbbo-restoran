<?php

namespace App\Http\Controllers;

class ChefController extends Controller{
    public function view(){
        return view ('Chef/index');
    }

}

?>
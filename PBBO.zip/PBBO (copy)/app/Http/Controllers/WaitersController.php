<?php

namespace App\Http\Controllers;

class WaitersController extends Controller{
    public function view(){
        return view('Waiters/index');
    }

}

?>